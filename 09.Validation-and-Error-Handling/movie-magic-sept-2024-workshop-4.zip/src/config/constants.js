export const JWT_SECRET = process.env.JWT_SECRET || '98132hfsdiauhf874o2q3hfb420f9udias08u1213'; 
